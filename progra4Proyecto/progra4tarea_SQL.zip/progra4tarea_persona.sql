-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: progra4tarea
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `persona`
--

DROP TABLE IF EXISTS `persona`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `persona` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `apellidos` varchar(45) DEFAULT NULL,
  `user` varchar(45) DEFAULT NULL,
  `pass` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89094348 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persona`
--

LOCK TABLES `persona` WRITE;
/*!40000 ALTER TABLE `persona` DISABLE KEYS */;
INSERT INTO `persona` VALUES (2,'Yei','test2','test2','test2'),(3,'test2','test2','test2','test2'),(4,'t','t','t','t'),(5,'cinvo','cinvo','cinvo','cinvo'),(6,'kiki','kiki','kiki','kiki'),(7,'null','null','Mari','Mari'),(9,'test2','test2','test2','test2'),(10,'test2','test2','test2','test2'),(11,'nico13','Camacho Briceño','nico13','nico13'),(12,'test3','test3','test3','test3'),(13,'fff','fff','fff','fff'),(21,'s','s','s','s'),(23,'s','','',''),(67,'t','t','t','t'),(333,'33','33','34','34'),(999,'test','test','test','test'),(3363,'d','d','d','d'),(4434,'fff','fff','fff','ffff'),(11111,'felipe','camacho','asdf','asdf'),(89094326,'felipe','Camacho','felipe','a'),(89094327,'t','t','t','t'),(89094328,'t','t','t','t'),(89094329,'ff','ff','ff','ff'),(89094330,'test','test','test','test'),(89094331,'test','test','test','test'),(89094332,'gg','gg','gg','gg'),(89094333,'jj','jj','jj','jj'),(89094334,'bb','bb','bb','bb'),(89094335,'xx','xx','xx','xx'),(89094336,'nn','nn','nn','nn'),(89094337,'ss','ss','ss','ss'),(89094338,'qq','qq','qq','qq'),(89094339,'cc','cc','ccc','cc'),(89094340,'mm','mm','mm','mm'),(89094341,'mm','mm','mm','mm'),(89094342,'gdg','fgd','dgf','gfdgdf'),(89094343,'bb','bb','bb','bb'),(89094344,'bb','bb','bb','bb'),(89094345,'tr','trtr','rtr','rtr'),(89094346,'yyy','yyy','yyy','yyy'),(89094347,'ccc','ccc','cccc','cccc');
/*!40000 ALTER TABLE `persona` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-10 11:15:26
