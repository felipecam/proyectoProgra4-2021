-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: progra4tarea
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `correo`
--

DROP TABLE IF EXISTS `correo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `correo` (
  `destinatario` varchar(100) DEFAULT NULL,
  `remitente` varchar(100) NOT NULL,
  `asunto` varchar(100) DEFAULT NULL,
  `body` varchar(500) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`fecha`,`remitente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `correo`
--

LOCK TABLES `correo` WRITE;
/*!40000 ALTER TABLE `correo` DISABLE KEYS */;
INSERT INTO `correo` VALUES ('\"jmailulatina@gmail.com\" <jmailulatina@gmail.com>','Felipe Camacho <jfelipecamacho@hotmail.com>','asd','ada\r\n\r\nSent from Mail<https://go.microsoft.com/fwlink/?LinkId=550986> for Windows 10\r\n\r\n','2021-08-06 20:22:04'),('\"jmailulatina@gmail.com\" <jmailulatina@gmail.com>','Felipe Camacho <jfelipecamacho@hotmail.com>','hh','hh\r\n\r\nSent from Mail<https://go.microsoft.com/fwlink/?LinkId=550986> for Windows 10\r\n\r\n','2021-08-09 10:39:36'),('\"jmailulatina@gmail.com\" <jmailulatina@gmail.com>','Felipe Camacho <jfelipecamacho@hotmail.com>','sfdsdf','dsfsd\r\n\r\nSent from Mail<https://go.microsoft.com/fwlink/?LinkId=550986> for Windows 10\r\n\r\n','2021-08-09 10:57:28'),('\"jmailulatina@gmail.com\" <jmailulatina@gmail.com>','Felipe Camacho <jfelipecamacho@hotmail.com>','sds','ds\r\n\r\n','2021-08-09 11:02:08'),('\"jmailulatina@gmail.com\" <jmailulatina@gmail.com>','Felipe Camacho <jfelipecamacho@hotmail.com>','cc','cc\r\n\r\nSent from Mail<https://go.microsoft.com/fwlink/?LinkId=550986> for Windows 10\r\n\r\n','2021-08-09 11:03:08'),('\"jmailulatina@gmail.com\" <jmailulatina@gmail.com>','Felipe Camacho <jfelipecamacho@hotmail.com>','ii','ii\r\n\r\n','2021-08-09 11:19:54'),('\"jmailulatina@gmail.com\" <jmailulatina@gmail.com>','Felipe Camacho <jfelipecamacho@hotmail.com>','bb','bb\r\n\r\nSent from Mail<https://go.microsoft.com/fwlink/?LinkId=550986> for Windows 10\r\n\r\n','2021-08-09 12:20:24'),('\"jmailulatina@gmail.com\" <jmailulatina@gmail.com>','Felipe Camacho <jfelipecamacho@hotmail.com>','asdasd','asdads\r\n=\r\n\r\n','2021-08-09 12:44:17'),('\"jmailulatina@gmail.com\" <jmailulatina@gmail.com>','Felipe Camacho <jfelipecamacho@hotmail.com>','yy','yy\r\n\r\nSent from Mail<https://go.microsoft.com/fwlink/?LinkId=550986> for Windows 10\r\n\r\n','2021-08-09 12:48:16'),('\"jmailulatina@gmail.com\" <jmailulatina@gmail.com>','Felipe Camacho <jfelipecamacho@hotmail.com>','tttt','tttt\r\n\r\nSent from Mail<https://go.microsoft.com/fwlink/?LinkId=550986> for Windows 10\r\n\r\n','2021-08-09 12:48:26'),('\"jmailulatina@gmail.com\" <jmailulatina@gmail.com>','Felipe Camacho <jfelipecamacho@hotmail.com>','practica','practica\r\n\r\nSent from Mail<https://go.microsoft.com/fwlink/?LinkId=550986> for Windows 10\r\n\r\n','2021-08-09 13:02:19'),('jmailulatina@gmail.com','Felipe Camacho <felipecb09@gmail.com>','progra','progra\r\n','2021-08-10 09:18:19'),('jmailulatina@gmail.com','Felipe Camacho <felipecb09@gmail.com>','progra4','progra4\r\nprogra4\r\nsaludos\r\n','2021-08-10 09:19:39'),('\"jmailulatina@gmail.com\" <jmailulatina@gmail.com>','Felipe Camacho <jfelipecamacho@hotmail.com>','test','test\r\n\r\nSent from Mail<https://go.microsoft.com/fwlink/?LinkId=550986> for Windows 10\r\n\r\n','2021-08-10 09:20:26'),('jmailulatina@gmail.com','Felipe Camacho <felipecb09@gmail.com>','ttt','tttt\r\n','2021-08-10 09:27:00'),('jmailulatina@gmail.com','Felipe Camacho <felipecb09@gmail.com>','yy','yy\r\n','2021-08-10 09:28:43');
/*!40000 ALTER TABLE `correo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-10 11:15:27
